#ifndef PIECE_COLOR_H
#define PIECE_COLOR_H

enum class PieceColor : int
{
	BLACK,
	WHITE
};

#endif